<?php 

include 'views/viewIndex.php';

?>