<?php


/* 
cargamos el crud_funciones
*/
include 'libs/crud_funciones.php';


# Cargamos model.editar
include 'models/model.mostrar.php';


/*
Cargamos la vista con el formulario
*/
include 'views/view.mostrar.php';

?>