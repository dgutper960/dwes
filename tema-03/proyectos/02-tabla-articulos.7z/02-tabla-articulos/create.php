<?php

/* 
cargamos el crud_funciones
*/
include 'libs/crud_funciones.php';

/*
cargamos el modelo
*/
include 'models/model.create.php';


/*
cargamos la vista
*/
include 'views/view.index.php';


?>