<header class="pb-3 mb-4 border-bottom">
<i class="bi bi-pc-display-horizontal"></i>
<span class="fs-4">Proyecto 3.2 - Artículos Informáticos</span>
</header>