<?php

include 'libs/crud_funciones.php';

include 'models/model.eliminar.php';

include 'views/view.index.php';

?>