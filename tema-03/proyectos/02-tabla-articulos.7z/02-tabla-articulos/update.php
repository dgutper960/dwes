<?php

/*

        Controlador: update.php
        Descripción: Muestra tabla actualizada

*/

//Librería
include "libs/crud_funciones.php";

// Cargar el modelo
include "models/model.update.php";

//Vista
include "views/view.index.php";