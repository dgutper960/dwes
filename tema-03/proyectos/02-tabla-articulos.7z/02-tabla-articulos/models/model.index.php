<?php
/*
llamamos a las categorias
 */

$categorias = generar_categoria();

/*
llamamos a la tabla de artículos
*/
$articulos = generar_tabla();


?>