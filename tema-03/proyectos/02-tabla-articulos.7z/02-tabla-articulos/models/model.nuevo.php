<?php 

# Cargamos las categorías
$categorias = generar_categoria();




?>