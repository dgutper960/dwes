<?php


/* 
cargamos el crud_funciones
*/
include 'libs/crud_funciones.php';


# Cargamos model.nuevo
include 'models/model.nuevo.php';


/*
Cargamos la vista con el formulario
*/
include 'views/view.nuevo.php';

?>