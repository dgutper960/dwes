<?php


/* 
cargamos el crud_funciones
*/
include 'libs/crud_funciones.php';


# Cargamos model.editar
include 'models/model.editar.php';


/*
Cargamos la vista con el formulario
*/
include 'views/view.editar.php';

?>