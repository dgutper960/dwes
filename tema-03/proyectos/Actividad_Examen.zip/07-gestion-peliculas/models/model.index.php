<?php

    /*
        fichero: model.index.php
        Descripción: modelo del proceso index.php

    */
    # Carcamos los arrays
    $paises = getPaises();
    $generos = getGeneros();
    $peliculas = getPeliculas();

    
    
?>