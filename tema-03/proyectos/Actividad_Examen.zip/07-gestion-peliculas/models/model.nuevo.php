<?php

    /*
        fichero: model.nuevo.php
        Descripción: modelo del proceso nuevo.php. 

    */
    # Cargamos las tablas
    $paises = getPaises();
    $generos = getGeneros();
    $peliculas = getPeliculas();

   

    
?>