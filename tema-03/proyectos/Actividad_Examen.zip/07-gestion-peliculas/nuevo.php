<?php

# Cargamos las funciones
include("lib/funciones.php");

# Cargamos el modelo
include("models/model.nuevo.php");

# Cargamos la vista
include("views/view.nuevo.php");
    

?>