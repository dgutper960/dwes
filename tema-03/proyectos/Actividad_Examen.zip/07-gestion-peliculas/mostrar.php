<?php

    include ("lib/funciones.php");

    include ("models/model.mostrar.php");

    include ("views/view.mostrar.php");

?>