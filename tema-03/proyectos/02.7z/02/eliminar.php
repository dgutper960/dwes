<?php
# Libreria
include 'libs/crud_funciones.php';

# Modelo
include 'models/modelIndex.php';
include 'models/modelEliminar.php';

# Vista
include 'views/viewIndex.php';

?>