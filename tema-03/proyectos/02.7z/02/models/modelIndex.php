<?php

/* generamos un array con los detalles de los libros */


$libros = [
    [
        "id" => 1,
        "titulo" => "El principio del fin",
        "autor" => "William Goldman",
        "genero" => "Drama",
        "precio" => 15.99
    ],[
        "id" => 2, 
        "titulo" => "El arte de la guerra", 
        "autor" => "Sun Tzu", 
        "genero" => "Estrategia", 
        "precio" => 14.99
    ],[
        "id" => 3, 
        "titulo" => "Cien años de soledad", 
        "autor" => "Gabriel García Márquez", 
        "genero" => "Novela", 
        "precio" => 18.99
    ],[
        "id" => 4,
        "titulo" => "Crónica de una muerte anunciada", 
        "autor" => "Gabriel García Márquez", 
        "genero" => "Novela",
        "precio" => 17.99
    ],[
        "id" => 5, 
        "titulo" => "Moby Dick", 
        "autor" => "Herman Melville", 
        "genero" => "Aventura", 
        "precio" => 19.99
    ]
];

?>
