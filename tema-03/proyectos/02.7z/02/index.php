<?php

include 'models/modelIndex.php';

include 'views/viewIndex.php';


?>