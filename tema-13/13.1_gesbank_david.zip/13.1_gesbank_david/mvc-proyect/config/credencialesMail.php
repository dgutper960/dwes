<?php
/**
 * Definimos constantes que usaremos en el controlador
 * ¡¡IMPORTANTE!!
 * - Por motivos de seguridad 
 *   estas credenciales no se pueden subir al repositorio
 *      - PARA LAS PRUEBAS DEBERAN RELLENARSE LOS CAMPOS VACÍOS DE LAS SIG CONSTANTES
 *          USUARIO = email del ususario que hace las pruebas
 *          PASS = contraseña de aplicación del email que se usa para las pruebas
 */
define('USUARIO', '');
define('PASS', '');