## Mostrar rol en el CRUD de usuarios
// 1. Preparar nuevas consultas que muestre:
    - Todos los usuarios + atributos -> role_id, role_name
    - Usuario por ID + atributos -> role_id, role_name

// 2. Edita la clase classUser
    - Añade los atributos: 
        - role_id
        - role_name

// 3. Editar los métodos del controlador create y update parta adaptarlos a las propiedades del objeto

// 4. Editar el CRUD de main para mostar el rol de cada usuario

// 5. Editar la vista editar para mostrar el select del rol