<?php
# Configuración básica aplicación MVC

# Ruta absoluta

define('URL', 'http://localhost/dwes/tema-08/proyectos/8.1_proyecto_album/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'album');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
