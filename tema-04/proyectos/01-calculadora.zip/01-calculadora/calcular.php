<?php

#cargamos la clase
include("class/class.calculadora.php");


# cargamos el modelo
include("models/model.calcular.php");

# Cargamos la vista
include("views/view.resultado.php");


?>