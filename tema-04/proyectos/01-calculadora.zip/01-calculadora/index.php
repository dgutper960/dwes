<?php

#cargamos la clase
include("class/class.calculadora.php");


# cargamos el modelo 
// No requerido

# Cargamos la vista
include("views/view.index.php");


?>