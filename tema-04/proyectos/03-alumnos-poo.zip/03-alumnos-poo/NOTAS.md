## El DateTime debe tener un formato personalizado

## Revisar el error del tratamiento como string en asignaturas en el constructor
