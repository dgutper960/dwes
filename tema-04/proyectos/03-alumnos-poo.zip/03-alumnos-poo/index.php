<?php

    /*

        Controlador: index.php
        Descripción: muestra los detalles de  los libros ordenados  por id

    */

    # Librería
    include 'class/class.alumno.php';
    include 'class/class.arrayAlumnos.php';

    # Model
    include 'models/model.index.php';

    # Vista
    include 'views/view.index.php';

?>