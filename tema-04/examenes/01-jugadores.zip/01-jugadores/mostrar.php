<?php


// cargamos las clases
include("class/class.jugador.php");
include("class/class.arrayJugadores.php");

// cargamos el modelo
include("models/model.mostrar.php");

// cargamos la vista
include("views/view.mostrar.php");
    

?>