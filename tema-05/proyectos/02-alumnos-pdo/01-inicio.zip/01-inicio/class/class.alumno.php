<?php

/**
 * DEBEMOS CREAR UNA CLASE ALUMNO
 * LOS ATRIBUTOS DEBEN DE SER EXACTAMENTE LOS MISMOS
 * Y EN EL MISMO ORDEN QUE LA TABLA DE LA BBDD
 */

 class Alumno{

    public $id;

    public $nombre;
    public $apellido;
    public $email;
    public $telefono;
    public $direccion;

    public $poblacion;

    public $provincia;

    public $nacinalidad;

    public $dni;

    public $fechaNac;

    public $id_curso;

    /**
     * REVISAR ATRIBUTOS
     */

 }



?>