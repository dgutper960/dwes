
<?php 
    
    // cargamos el modelo
    include 'models/modelBinario.php';


    // cargamos el controlador
    include 'views/viewCalculo.php'; 

?>