
<?php 

    // cargamos el modelo
    include 'models/modelOctal.php';


    // cargamos el controlador
     include 'views/viewCalculo.php'; 

?>