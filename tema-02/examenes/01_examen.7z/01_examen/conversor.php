
<?php 

    // cargamos el modelo
    include 'models/modelConversor.php'; 

    // cargamos el controlador
    include 'views/viewConversor.php'; 
    
    
?>