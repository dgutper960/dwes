
<?php 

    // cargamos el modelo
    include 'models/modelHexad.php'; 

    // cargamos el controlador
    include 'views/viewCalculo.php'; 


?>