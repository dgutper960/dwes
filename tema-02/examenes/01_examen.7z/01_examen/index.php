<?php

    /*

        Controlador: index.php
        Descripción: Carga el  formulario de  datos  para  la conversión

    */

    # Model
    

    # Vista
    include 'views/viewIndex.php';
    

?>