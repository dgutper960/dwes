

<?php $__env->startSection('titulo', 'Articulos Informática'); ?>
<?php $__env->startSection('subtitulo', 'Articulos disponibles'); ?>

<?php $__env->startSection('contenido'); ?>
    <!-- Menú -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">Home</a>
            <a class="navbar-brand" href="#">Artículos</a>
        </div>
    </nav>

    <!--
        Cabecera
-->
    
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Descripción</th>
                <th scope="col">Categoría</th>
                <th scope="col">Unidades</th>
                <th scope="col">Precio Coste</th>
                <th scope="col">Precio Venta</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($articulo['id']); ?></th>
                    <td><?php echo e($articulo['descripcion']); ?></td>
                    <td><?php echo e($articulo['categoria']); ?></td>
                    <td><?php echo e($articulo['stock']); ?></td>
                    <td><?php echo e($articulo['precio_coste']); ?></td>
                    <td><?php echo e($articulo['precio_venta']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Número de registros -->
    <p>Número de registros: <?php echo e(count($articulos)); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dwes\tema-12\actividades\actividad_12.7_david\resources\views/articulos/articulos.blade.php ENDPATH**/ ?>