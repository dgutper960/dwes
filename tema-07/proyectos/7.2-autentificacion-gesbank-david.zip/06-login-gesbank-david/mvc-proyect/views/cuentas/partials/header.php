<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
            <div class="container"><br><br><br>
                <h4 class="display-7"><?= $this->title ?> </h4>
            </div>
        </div>
    </hgroup>
</header>