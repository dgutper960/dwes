<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h4 class="display-7">Gestion Bancaria - GESBANK  </h4>
            <p class="lead">Tema 6 - DWES - Curso 23/24</p>
        </div>
        </div>
    </hgroup>
</header>